import { useEffect, useRef, useState } from "react";
import { X } from "lucide-react";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { cn } from "@/lib/utils";

const readFileAsDataUrl = (file: File) =>
  new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(typeof reader.result === "string" ? reader.result : "");
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(file);
  });

export type CreateProductPayload = {
  name: string;
  description: string;
  specification: string;
  /** Selling price */
  price: number;
  actualPrice: number | null;
  stock: number;
  minStock: number;
  /** Cover image file (optional if videoFile is set) */
  coverFile: File | null;
  /** Short product video (optional if coverFile is set) */
  videoFile: File | null;
  variantImageDataUrls: [string | null, string | null, string | null];
  isLimitedAvailability: boolean;
  showInCarousel: boolean;
};

type Props = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onCreate: (data: CreateProductPayload) => Promise<void>;
};

const SimpleProductCreateDialog = ({ open, onOpenChange, onCreate }: Props) => {
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [specification, setSpecification] = useState("");
  const [price, setPrice] = useState("");
  const [actualPrice, setActualPrice] = useState("");
  const [stock, setStock] = useState("");
  const [minStock, setMinStock] = useState("");
  const [coverLabel, setCoverLabel] = useState("No file chosen");
  const [coverPreview, setCoverPreview] = useState<string | null>(null);
  const [coverFile, setCoverFile] = useState<File | null>(null);
  const coverInputRef = useRef<HTMLInputElement | null>(null);
  const [videoLabel, setVideoLabel] = useState("No file chosen");
  const [videoPreviewUrl, setVideoPreviewUrl] = useState<string | null>(null);
  const [videoFile, setVideoFile] = useState<File | null>(null);
  const videoInputRef = useRef<HTMLInputElement | null>(null);
  const variantInputRefs = useRef<Array<HTMLInputElement | null>>([null, null, null]);
  const [variantLabels, setVariantLabels] = useState<[string, string, string]>(["No file", "No file", "No file"]);
  const [variantPreviews, setVariantPreviews] = useState<[string | null, string | null, string | null]>([
    null,
    null,
    null,
  ]);
  const [isLimitedAvailability, setIsLimitedAvailability] = useState(false);
  const [showInCarousel, setShowInCarousel] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    if (!open) {
      setName("");
      setDescription("");
      setSpecification("");
      setPrice("");
      setActualPrice("");
      setStock("");
      setMinStock("");
      setCoverLabel("No file chosen");
      setCoverPreview(null);
      setCoverFile(null);
      setVideoLabel("No file chosen");
      setVideoPreviewUrl((prev) => {
        if (prev) URL.revokeObjectURL(prev);
        return null;
      });
      setVideoFile(null);
      setVariantLabels(["No file", "No file", "No file"]);
      setVariantPreviews([null, null, null]);
      setIsLimitedAvailability(false);
      setShowInCarousel(false);
      setIsSaving(false);
    }
  }, [open]);

  useEffect(() => {
    return () => {
      if (videoPreviewUrl) URL.revokeObjectURL(videoPreviewUrl);
    };
  }, [videoPreviewUrl]);

  const handleBack = () => onOpenChange(false);
  const clearCover = () => {
    setCoverLabel("No file chosen");
    setCoverPreview(null);
    setCoverFile(null);
    if (coverInputRef.current) coverInputRef.current.value = "";
  };
  const clearVideo = () => {
    setVideoLabel("No file chosen");
    if (videoPreviewUrl) URL.revokeObjectURL(videoPreviewUrl);
    setVideoPreviewUrl(null);
    setVideoFile(null);
    if (videoInputRef.current) videoInputRef.current.value = "";
  };
  const clearVariantImage = (index: 0 | 1 | 2) => {
    setVariantLabels((prev) => {
      const next = [...prev] as [string, string, string];
      next[index] = "No file";
      return next;
    });
    setVariantPreviews((prev) => {
      const next = [...prev] as [string | null, string | null, string | null];
      next[index] = null;
      return next;
    });
    const ref = variantInputRefs.current[index];
    if (ref) ref.value = "";
  };

  const handleCoverFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) {
      clearCover();
      return;
    }
    if (!file.type.startsWith("image/")) {
      clearCover();
      return;
    }
    setCoverLabel(file.name);
    setCoverFile(file);
    setCoverPreview(await readFileAsDataUrl(file));
  };

  const handleVideoFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) {
      clearVideo();
      return;
    }
    if (!file.type.startsWith("video/")) {
      clearVideo();
      return;
    }
    setVideoLabel(file.name);
    if (videoPreviewUrl) URL.revokeObjectURL(videoPreviewUrl);
    const url = URL.createObjectURL(file);
    setVideoPreviewUrl(url);
    setVideoFile(file);
  };

  const handleVariantFile = async (index: 0 | 1 | 2, e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    setVariantLabels((prev) => {
      const next = [...prev] as [string, string, string];
      next[index] = file ? file.name : "No file";
      return next;
    });
    if (!file) {
      setVariantPreviews((prev) => {
        const next = [...prev] as [string | null, string | null, string | null];
        next[index] = null;
        return next;
      });
      return;
    }
    const dataUrl = await readFileAsDataUrl(file);
    setVariantPreviews((prev) => {
      const next = [...prev] as [string | null, string | null, string | null];
      next[index] = dataUrl;
      return next;
    });
  };

  const handleSubmit = async () => {
    const trimmed = name.trim();
    const p = Number(price);
    if (!trimmed || !Number.isFinite(p) || p < 0) return;
    if (!coverFile && !videoFile) return;

    let ap: number | null = null;
    if (actualPrice.trim() !== "") {
      const n = Number(actualPrice);
      if (!Number.isFinite(n) || n < 0) return;
      ap = n;
    }

    const st = stock.trim() === "" ? 0 : Math.floor(Number(stock));
    if (!Number.isFinite(st) || st < 0) return;
    const minS = minStock.trim() === "" ? 0 : Math.floor(Number(minStock));
    if (!Number.isFinite(minS) || minS < 0) return;

    setIsSaving(true);
    try {
      await onCreate({
        name: trimmed,
        description: description.trim(),
        specification: specification.trim(),
        price: p,
        actualPrice: ap,
        stock: st,
        minStock: minS,
        coverFile,
        videoFile,
        variantImageDataUrls: [...variantPreviews],
        isLimitedAvailability,
        showInCarousel,
      });
      onOpenChange(false);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent
        className={cn(
          "max-w-3xl p-0 gap-0 border-0 bg-transparent shadow-none sm:max-w-3xl max-h-[90vh] overflow-y-auto",
          "[&>button]:hidden",
        )}
      >
        <div className="rounded-xl border border-border/60 bg-card shadow-lg p-6">
          <div className="flex items-center justify-between gap-3 mb-2">
            <h2 className="text-base font-semibold text-foreground">New Products</h2>
            <button
              type="button"
              onClick={handleBack}
              className="rounded-md bg-[#000533] text-white text-sm font-medium px-4 py-2 hover:opacity-90 transition-opacity"
            >
              Back
            </button>
          </div>
          <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-4">Product Details</p>

          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs text-muted-foreground mb-1.5">Product Name</label>
                <input
                  placeholder="Type Name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full rounded-md border border-border px-3 py-2.5 text-sm text-foreground bg-background outline-none focus:ring-2 focus:ring-primary/20"
                />
              </div>
              <div>
                <label className="block text-xs text-muted-foreground mb-1.5">Selling Price (₹)</label>
                <input
                  placeholder="Type Price"
                  type="number"
                  min={0}
                  step="0.01"
                  value={price}
                  onChange={(e) => setPrice(e.target.value)}
                  className="w-full rounded-md border border-border px-3 py-2.5 text-sm text-foreground bg-background outline-none focus:ring-2 focus:ring-primary/20"
                />
              </div>
              <div>
                <label className="block text-xs text-muted-foreground mb-1.5">Actual Price (₹)</label>
                <input
                  placeholder="Type Price"
                  type="number"
                  min={0}
                  step="0.01"
                  value={actualPrice}
                  onChange={(e) => setActualPrice(e.target.value)}
                  className="w-full rounded-md border border-border px-3 py-2.5 text-sm text-foreground bg-background outline-none focus:ring-2 focus:ring-primary/20"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs text-muted-foreground mb-1.5">Stock</label>
                <input
                  placeholder="Type Stock"
                  type="number"
                  min={0}
                  step={1}
                  value={stock}
                  onChange={(e) => setStock(e.target.value)}
                  className="w-full rounded-md border border-border px-3 py-2.5 text-sm text-foreground bg-background outline-none focus:ring-2 focus:ring-primary/20"
                />
              </div>
              <div>
                <label className="block text-xs text-muted-foreground mb-1.5">Min stock (alert threshold)</label>
                <input
                  placeholder="e.g. 30"
                  type="number"
                  min={0}
                  step={1}
                  value={minStock}
                  onChange={(e) => setMinStock(e.target.value)}
                  className="w-full rounded-md border border-border px-3 py-2.5 text-sm text-foreground bg-background outline-none focus:ring-2 focus:ring-primary/20"
                />
              </div>
            </div>

            <div className="flex items-center gap-2 bg-muted/30 p-3 rounded-lg border border-border/50">
              <input
                type="checkbox"
                id="isLimited"
                checked={isLimitedAvailability}
                onChange={(e) => setIsLimitedAvailability(e.target.checked)}
                className="h-4 w-4 rounded border-border text-primary focus:ring-primary/20"
              />
              <div className="flex-1">
                <label htmlFor="isLimited" className="text-sm font-semibold text-foreground cursor-pointer block">
                  Force "Limited Availability" Badge
                </label>
                <p className="text-[10px] text-muted-foreground">
                  Shows the "Limited Availability" tag to users regardless of actual stock levels.
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 bg-muted/30 p-3 rounded-lg border border-border/50 mt-2">
              <input
                type="checkbox"
                id="showInCarousel"
                checked={showInCarousel}
                onChange={(e) => setShowInCarousel(e.target.checked)}
                className="h-4 w-4 rounded border-border text-primary focus:ring-primary/20"
              />
              <div className="flex-1">
                <label htmlFor="showInCarousel" className="text-sm font-semibold text-foreground cursor-pointer block">
                  Show in 3D Carousel
                </label>
                <p className="text-[10px] text-muted-foreground">
                  If selected, this product will appear in the 3D Carousel on the home page.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs text-muted-foreground mb-1.5">Cover image</label>
                <input
                  ref={coverInputRef}
                  type="file"
                  accept="image/*"
                  onChange={(e) => void handleCoverFile(e)}
                  className="text-sm"
                />
                <p className="text-xs text-muted-foreground mt-1">{coverLabel}</p>
                {coverPreview ? (
                  <div className="relative mt-2 inline-block">
                    <img src={coverPreview} alt="" className="h-20 w-20 rounded object-cover border border-border" />
                    <button
                      type="button"
                      onClick={clearCover}
                      className="absolute -top-2 -right-2 h-7 w-7 rounded-full bg-background border border-border shadow-sm flex items-center justify-center hover:bg-muted"
                      aria-label="Remove image"
                    >
                      <X className="h-4 w-4" />
                    </button>
                  </div>
                ) : null}
              </div>
              <div>
                <label className="block text-xs text-muted-foreground mb-1.5">Short product video (optional)</label>
                <input
                  ref={videoInputRef}
                  type="file"
                  accept="video/*"
                  onChange={(e) => handleVideoFile(e)}
                  className="text-sm"
                />
                <p className="text-xs text-muted-foreground mt-1">{videoLabel}</p>
                {videoPreviewUrl ? (
                  <div className="relative mt-2 inline-block max-w-[200px]">
                    <video src={videoPreviewUrl} className="h-24 w-full rounded object-cover border border-border" muted playsInline controls />
                    <button
                      type="button"
                      onClick={clearVideo}
                      className="absolute -top-2 -right-2 h-7 w-7 rounded-full bg-background border border-border shadow-sm flex items-center justify-center hover:bg-muted"
                      aria-label="Remove video"
                    >
                      <X className="h-4 w-4" />
                    </button>
                  </div>
                ) : null}
              </div>
            </div>

            <div>
              <label className="block text-xs text-muted-foreground mb-2">Variant Images</label>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                {([0, 1, 2] as const).map((i) => (
                  <div key={i}>
                    <label className="block text-[11px] text-muted-foreground mb-1">Variant Image {i + 1}</label>
                    <input
                      ref={(el) => {
                        variantInputRefs.current[i] = el;
                      }}
                      type="file"
                      accept="image/*"
                      onChange={(e) => void handleVariantFile(i, e)}
                      className="text-sm w-full"
                    />
                    <p className="text-xs text-muted-foreground mt-1 truncate">{variantLabels[i]}</p>
                    {variantPreviews[i] ? (
                      <div className="relative mt-2 inline-block">
                        <img
                          src={variantPreviews[i]!}
                          alt=""
                          className="h-16 w-full max-w-[120px] rounded object-cover border border-border"
                        />
                        <button
                          type="button"
                          onClick={() => clearVariantImage(i)}
                          className="absolute -top-2 -right-2 h-7 w-7 rounded-full bg-background border border-border shadow-sm flex items-center justify-center hover:bg-muted"
                          aria-label={`Remove variant ${i + 1}`}
                        >
                          <X className="h-4 w-4" />
                        </button>
                      </div>
                    ) : null}
                  </div>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs text-muted-foreground mb-1.5">Product Description</label>
                <textarea
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  rows={4}
                  className="w-full rounded-md border border-border px-3 py-2.5 text-sm text-foreground bg-background outline-none focus:ring-2 focus:ring-primary/20 resize-y min-h-[100px]"
                />
              </div>
              <div>
                <label className="block text-xs text-muted-foreground mb-1.5">Product Specification</label>
                <textarea
                  value={specification}
                  onChange={(e) => setSpecification(e.target.value)}
                  rows={4}
                  className="w-full rounded-md border border-border px-3 py-2.5 text-sm text-foreground bg-background outline-none focus:ring-2 focus:ring-primary/20 resize-y min-h-[100px]"
                />
              </div>
            </div>

            <button
              type="button"
              onClick={() => void handleSubmit()}
              disabled={isSaving}
              className="w-full rounded-md bg-[#000533] text-white text-sm font-medium py-3 hover:opacity-90 transition-opacity disabled:opacity-50"
            >
              {isSaving ? "Creating..." : "Create"}
            </button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default SimpleProductCreateDialog;
